#!/bin/bash

echo "==> Instalando dependências do sistema..."
sudo apt update && sudo apt install -y docker.io docker-compose git

echo "==> Clonando o repositório (se necessário)..."
# git clone <url-do-repo> plataforma-gestao-remota
# cd plataforma-gestao-remota

echo "==> Subindo containers com Docker Compose..."
docker-compose up --build -d

echo "==> Finalizado!"
echo "Acesse o frontend em: http://localhost:3000"
echo "Acesse o backend em: http://localhost:5000"
