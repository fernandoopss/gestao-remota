#!/bin/bash

echo "==> Instalando PyInstaller..."
pip install pyinstaller

echo "==> Empacotando agente Linux..."
cd src/agents/linux
pyinstaller --onefile linux_agent.py

echo "==> Binário gerado em: dist/linux_agent"
