
# Plataforma de Gestão Remota

## 1. Visão Geral
A Plataforma de Gestão Remota foi projetada para monitorar e controlar dispositivos com sistemas operacionais Windows e Linux em ambientes corporativos ou de infraestrutura crítica.

A aplicação é composta por três módulos principais: **Backend (Flask)**, **Frontend (React)** e **Agentes de Monitoramento (Python)**.

## 2. Estrutura de Diretórios
```
- README.md
- docs/
    - 01_documentacao_tecnica_plataforma.pdf
    - 02_manual_instalacao.pdf
    - 03_manual_usuario.pdf
- relatorios/
    - relatorio_final.pdf
- arquitetura/
    - arquitetura.md
- src/
    - backend/         -> API Flask + banco
    - frontend/        -> Painel React
    - agents/          -> Agentes Linux/Windows
```

## 3. Backend
O backend é construído em Flask, com rotas REST para:
- Controle de dispositivos
- Autenticação
- Execução de comandos
- Transferência de arquivos
- Monitoramento

**Requisitos:**
- Python 3.11+
- PostgreSQL (via Docker)

O backend pode ser iniciado via Docker ou manualmente após configurar as variáveis de ambiente necessárias.

## 4. Frontend
Interface em React (Vite + Tailwind), com:
- Login administrativo
- Visualização de dispositivos conectados
- Envio de comandos remotos
- Monitoramento em tempo real

**Porta padrão:** `3000`

## 5. Agentes
Scripts Python para:
- Coleta de informações
- Execução de comandos remotos
- Upload/download de arquivos

**Instalação:**
- Linux: `bash install.sh`
- Windows: `install.bat`

## 6. Deploy com Docker Compose
O arquivo `docker-compose.yml` já está incluso na raiz do projeto.

**Para iniciar:**
```bash
docker-compose up --build -d
```

**Serviços:**
- Backend: http://localhost:5000
- Frontend: http://localhost:3000
- PostgreSQL: porta interna 5432

Ajuste as variáveis conforme necessário.
