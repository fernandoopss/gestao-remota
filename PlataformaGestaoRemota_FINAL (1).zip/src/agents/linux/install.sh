#!/bin/bash
"""
Script de Instalação do Agente de Monitoramento - Linux
Plataforma de Gestão Remota de Infraestrutura
"""

set -e

# Configurações
AGENT_NAME="monitoring-agent"
AGENT_USER="monitoring"
INSTALL_DIR="/opt/monitoring-agent"
CONFIG_DIR="/etc/monitoring-agent"
LOG_DIR="/var/log/monitoring-agent"
SERVICE_FILE="/etc/systemd/system/monitoring-agent.service"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funções auxiliares
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "Este script deve ser executado como root"
        exit 1
    fi
}

install_dependencies() {
    log_info "Instalando dependências..."
    
    # Detecta o gerenciador de pacotes
    if command -v apt-get &> /dev/null; then
        # Debian/Ubuntu
        apt-get update
        apt-get install -y python3 python3-pip python3-venv
    elif command -v yum &> /dev/null; then
        # CentOS/RHEL
        yum install -y python3 python3-pip
    elif command -v dnf &> /dev/null; then
        # Fedora
        dnf install -y python3 python3-pip
    elif command -v pacman &> /dev/null; then
        # Arch Linux
        pacman -S --noconfirm python python-pip
    else
        log_error "Gerenciador de pacotes não suportado"
        exit 1
    fi
}

create_user() {
    log_info "Criando usuário do agente..."
    
    if ! id "$AGENT_USER" &>/dev/null; then
        useradd --system --shell /bin/false --home-dir "$INSTALL_DIR" --create-home "$AGENT_USER"
        log_info "Usuário $AGENT_USER criado"
    else
        log_warn "Usuário $AGENT_USER já existe"
    fi
}

create_directories() {
    log_info "Criando diretórios..."
    
    mkdir -p "$INSTALL_DIR"
    mkdir -p "$CONFIG_DIR"
    mkdir -p "$LOG_DIR"
    
    chown -R "$AGENT_USER:$AGENT_USER" "$INSTALL_DIR"
    chown -R "$AGENT_USER:$AGENT_USER" "$LOG_DIR"
    chmod 755 "$CONFIG_DIR"
}

install_agent() {
    log_info "Instalando agente..."
    
    # Copia arquivos do agente
    cp -r ../common "$INSTALL_DIR/"
    cp -r ../linux/* "$INSTALL_DIR/"
    
    # Cria ambiente virtual Python
    python3 -m venv "$INSTALL_DIR/venv"
    
    # Instala dependências Python
    "$INSTALL_DIR/venv/bin/pip" install --upgrade pip
    "$INSTALL_DIR/venv/bin/pip" install psutil requests
    
    # Torna o script executável
    chmod +x "$INSTALL_DIR/linux_agent.py"
    
    # Ajusta permissões
    chown -R "$AGENT_USER:$AGENT_USER" "$INSTALL_DIR"
}

create_config() {
    log_info "Criando configuração..."
    
    cat > "$CONFIG_DIR/config.ini" << EOF
[server]
url = http://localhost:5000

[device]
name = $(hostname)
api_key = 

[agent]
heartbeat_interval = 30
metrics_interval = 10
command_check_interval = 5

[logging]
level = INFO
file = $LOG_DIR/agent.log
EOF

    chmod 644 "$CONFIG_DIR/config.ini"
    log_info "Arquivo de configuração criado em $CONFIG_DIR/config.ini"
}

create_service() {
    log_info "Criando serviço systemd..."
    
    cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Monitoring Agent
After=network.target
Wants=network.target

[Service]
Type=simple
User=$AGENT_USER
Group=$AGENT_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/linux_agent.py --config $CONFIG_DIR/config.ini --daemon
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    log_info "Serviço systemd criado"
}

configure_firewall() {
    log_info "Configurando firewall (se necessário)..."
    
    # UFW (Ubuntu/Debian)
    if command -v ufw &> /dev/null; then
        log_info "UFW detectado - nenhuma configuração necessária (agente faz conexões de saída)"
    fi
    
    # firewalld (CentOS/RHEL/Fedora)
    if command -v firewall-cmd &> /dev/null; then
        log_info "firewalld detectado - nenhuma configuração necessária (agente faz conexões de saída)"
    fi
}

show_status() {
    log_info "Status da instalação:"
    echo "  Diretório de instalação: $INSTALL_DIR"
    echo "  Arquivo de configuração: $CONFIG_DIR/config.ini"
    echo "  Logs: $LOG_DIR/"
    echo "  Usuário: $AGENT_USER"
    echo ""
    log_info "Para iniciar o agente:"
    echo "  sudo systemctl start monitoring-agent"
    echo ""
    log_info "Para habilitar inicialização automática:"
    echo "  sudo systemctl enable monitoring-agent"
    echo ""
    log_info "Para verificar status:"
    echo "  sudo systemctl status monitoring-agent"
    echo ""
    log_warn "IMPORTANTE: Edite $CONFIG_DIR/config.ini para configurar a URL do servidor!"
}

uninstall() {
    log_info "Desinstalando agente..."
    
    # Para e desabilita o serviço
    systemctl stop monitoring-agent 2>/dev/null || true
    systemctl disable monitoring-agent 2>/dev/null || true
    
    # Remove arquivos
    rm -f "$SERVICE_FILE"
    rm -rf "$INSTALL_DIR"
    rm -rf "$CONFIG_DIR"
    rm -rf "$LOG_DIR"
    
    # Remove usuário
    userdel "$AGENT_USER" 2>/dev/null || true
    
    systemctl daemon-reload
    
    log_info "Agente desinstalado com sucesso"
}

main() {
    case "${1:-install}" in
        install)
            log_info "Iniciando instalação do Agente de Monitoramento..."
            check_root
            install_dependencies
            create_user
            create_directories
            install_agent
            create_config
            create_service
            configure_firewall
            show_status
            log_info "Instalação concluída com sucesso!"
            ;;
        uninstall)
            log_info "Iniciando desinstalação do Agente de Monitoramento..."
            check_root
            uninstall
            ;;
        *)
            echo "Uso: $0 [install|uninstall]"
            exit 1
            ;;
    esac
}

main "$@"

