#!/usr/bin/env python3
"""
Agente de Monitoramento para Linux
Plataforma de Gestão Remota de Infraestrutura

Este agente coleta métricas do sistema, executa comandos remotos e gerencia
transferências de arquivos em sistemas Linux.
"""

import os
import sys
import json
import time
import psutil
import socket
import platform
import subprocess
import configparser
from pathlib import Path
from typing import Dict, Any

# Adiciona o diretório common ao path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'common'))
from base_agent import BaseAgent

class LinuxAgent(BaseAgent):
    """Agente de monitoramento para sistemas Linux"""
    
    def __init__(self, config_file: str = None):
        # Carrega configuração
        self.config = self._load_config(config_file)
        
        # Informações do dispositivo
        device_info = {
            'name': self.config.get('device', 'name', fallback=socket.gethostname()),
            'hostname': socket.gethostname(),
            'ip_address': self._get_ip_address(),
            'operating_system': 'Linux',
            'os_version': platform.platform(),
            'agent_version': '1.0.0'
        }
        
        server_url = self.config.get('server', 'url', fallback='http://localhost:5000')
        api_key = self.config.get('device', 'api_key', fallback='')
        
        super().__init__(server_url, api_key, device_info)
    
    def _load_config(self, config_file: str = None) -> configparser.ConfigParser:
        """Carrega configuração do arquivo"""
        config = configparser.ConfigParser()
        
        if config_file is None:
            # Procura arquivo de configuração em locais padrão
            config_paths = [
                '/etc/monitoring-agent/config.ini',
                '/usr/local/etc/monitoring-agent/config.ini',
                os.path.expanduser('~/.monitoring-agent/config.ini'),
                './config.ini'
            ]
            
            for path in config_paths:
                if os.path.exists(path):
                    config_file = path
                    break
        
        if config_file and os.path.exists(config_file):
            config.read(config_file)
            print(f"Configuração carregada de: {config_file}")
        else:
            print("Arquivo de configuração não encontrado, usando valores padrão")
        
        return config
    
    def _get_ip_address(self) -> str:
        """Obtém o endereço IP principal do sistema"""
        try:
            # Conecta a um endereço externo para descobrir o IP local
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except Exception:
            return "127.0.0.1"
    
    def collect_metrics(self) -> Dict[str, Any]:
        """Coleta métricas do sistema Linux"""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memória
            memory = psutil.virtual_memory()
            
            # Disco (partição raiz)
            disk = psutil.disk_usage('/')
            
            # Rede
            network = psutil.net_io_counters()
            
            # Uptime
            uptime = time.time() - psutil.boot_time()
            
            metrics = {
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'memory_used': memory.used,
                'memory_total': memory.total,
                'disk_percent': disk.percent,
                'disk_used': disk.used,
                'disk_total': disk.total,
                'network_bytes_sent': network.bytes_sent,
                'network_bytes_recv': network.bytes_recv,
                'uptime': uptime
            }
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Erro ao coletar métricas: {e}")
            return {}
    
    def execute_command(self, command: str) -> tuple:
        """Executa um comando no sistema Linux"""
        try:
            # Executa o comando usando subprocess
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutos de timeout
            )
            
            return result.stdout, result.stderr, result.returncode
            
        except subprocess.TimeoutExpired:
            return "", "Comando expirou (timeout de 5 minutos)", 124
        except Exception as e:
            return "", f"Erro ao executar comando: {e}", 1
    
    def process_command(self, command: Dict[str, Any]):
        """Processa um comando recebido do servidor"""
        command_id = command.get('command_id')
        command_text = command.get('command')
        
        if not command_id or not command_text:
            return
        
        self.logger.info(f"Executando comando {command_id}: {command_text}")
        
        # Atualiza status para "running"
        self.update_command_status(command_id, 'running')
        
        # Executa o comando
        output, error_output, exit_code = self.execute_command(command_text)
        
        # Submete o resultado
        self.submit_command_result(command_id, output, error_output, exit_code)
        
        self.logger.info(f"Comando {command_id} concluído com código de saída {exit_code}")
    
    def process_file_transfers(self):
        """Processa transferências de arquivo pendentes"""
        transfers = self.get_pending_transfers()
        
        for transfer in transfers:
            transfer_id = transfer.get('id')
            operation_type = transfer.get('operation_type')
            
            if operation_type == 'upload':
                self._handle_upload(transfer)
            elif operation_type == 'download':
                self._handle_download(transfer)
    
    def _handle_upload(self, transfer: Dict[str, Any]):
        """Processa upload de arquivo"""
        # Implementação simplificada - em produção seria mais robusta
        transfer_id = transfer.get('id')
        self.logger.info(f"Processando upload {transfer_id}")
        
        # Atualiza status
        self.update_transfer_status(transfer_id, 'in_progress', 0)
        
        # Simula processamento
        time.sleep(2)
        
        # Marca como concluído
        self.update_transfer_status(transfer_id, 'completed', 100)
    
    def _handle_download(self, transfer: Dict[str, Any]):
        """Processa download de arquivo"""
        # Implementação simplificada - em produção seria mais robusta
        transfer_id = transfer.get('id')
        file_path = transfer.get('file_path')
        
        self.logger.info(f"Processando download {transfer_id}: {file_path}")
        
        # Verifica se o arquivo existe
        if not os.path.exists(file_path):
            self.update_transfer_status(transfer_id, 'failed', 0, f"Arquivo não encontrado: {file_path}")
            return
        
        # Atualiza status
        self.update_transfer_status(transfer_id, 'in_progress', 0)
        
        # Simula processamento
        time.sleep(2)
        
        # Marca como concluído
        self.update_transfer_status(transfer_id, 'completed', 100)

def create_default_config():
    """Cria arquivo de configuração padrão"""
    config_dir = os.path.expanduser('~/.monitoring-agent')
    config_file = os.path.join(config_dir, 'config.ini')
    
    # Cria diretório se não existir
    os.makedirs(config_dir, exist_ok=True)
    
    config = configparser.ConfigParser()
    config['server'] = {
        'url': 'http://localhost:5000',
    }
    config['device'] = {
        'name': socket.gethostname(),
        'api_key': ''
    }
    config['agent'] = {
        'heartbeat_interval': '30',
        'metrics_interval': '10',
        'command_check_interval': '5'
    }
    
    with open(config_file, 'w') as f:
        config.write(f)
    
    print(f"Arquivo de configuração criado em: {config_file}")
    print("Edite o arquivo para configurar a URL do servidor e outras opções.")
    
    return config_file

def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Agente de Monitoramento Linux')
    parser.add_argument('--config', '-c', help='Arquivo de configuração')
    parser.add_argument('--create-config', action='store_true', help='Cria arquivo de configuração padrão')
    parser.add_argument('--daemon', '-d', action='store_true', help='Executa como daemon')
    
    args = parser.parse_args()
    
    if args.create_config:
        create_default_config()
        return
    
    # Cria e inicia o agente
    agent = LinuxAgent(args.config)
    
    try:
        if agent.start():
            if args.daemon:
                # Em modo daemon, executa indefinidamente
                while True:
                    time.sleep(60)
                    # Processa transferências de arquivo periodicamente
                    agent.process_file_transfers()
            else:
                # Em modo interativo, aguarda Ctrl+C
                print("Agente iniciado. Pressione Ctrl+C para parar.")
                while True:
                    time.sleep(1)
                    # Processa transferências de arquivo periodicamente
                    if int(time.time()) % 30 == 0:  # A cada 30 segundos
                        agent.process_file_transfers()
        else:
            print("Falha ao iniciar o agente")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\nParando agente...")
        agent.stop()
        print("Agente parado")

if __name__ == '__main__':
    main()

