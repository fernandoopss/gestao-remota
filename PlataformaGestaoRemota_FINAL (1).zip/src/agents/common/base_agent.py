#!/usr/bin/env python3
"""
Agente de Monitoramento - Módulo Comum
Plataforma de Gestão Remota de Infraestrutura

Este módulo contém funcionalidades comuns para os agentes Linux e Windows.
"""

import json
import time
import logging
import requests
import threading
from datetime import datetime
from typing import Dict, Any, Optional

class BaseAgent:
    """Classe base para agentes de monitoramento"""
    
    def __init__(self, server_url: str, api_key: str, device_info: Dict[str, Any]):
        self.server_url = server_url.rstrip('/')
        self.api_key = api_key
        self.device_info = device_info
        self.running = False
        self.logger = self._setup_logging()
        
        # Configurações
        self.heartbeat_interval = 30  # segundos
        self.metrics_interval = 10    # segundos
        self.command_check_interval = 5  # segundos
        
        # Threads
        self.heartbeat_thread = None
        self.metrics_thread = None
        self.command_thread = None
        
    def _setup_logging(self) -> logging.Logger:
        """Configura o sistema de logging"""
        logger = logging.getLogger('monitoring_agent')
        logger.setLevel(logging.INFO)
        
        # Handler para console
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(formatter)
        
        logger.addHandler(console_handler)
        return logger
    
    def register_device(self) -> bool:
        """Registra o dispositivo no servidor"""
        try:
            url = f"{self.server_url}/api/devices/register"
            response = requests.post(url, json=self.device_info, timeout=10)
            
            if response.status_code == 201:
                data = response.json()
                self.api_key = data.get('api_key', self.api_key)
                self.logger.info(f"Dispositivo registrado com sucesso: {data.get('device', {}).get('name')}")
                return True
            elif response.status_code == 409:
                self.logger.info("Dispositivo já registrado")
                return True
            else:
                self.logger.error(f"Erro ao registrar dispositivo: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro na comunicação com o servidor: {e}")
            return False
    
    def send_heartbeat(self) -> bool:
        """Envia heartbeat para o servidor"""
        try:
            url = f"{self.server_url}/api/devices/heartbeat"
            data = {
                'api_key': self.api_key,
                'status': {
                    'agent_version': '1.0.0',
                    'timestamp': datetime.utcnow().isoformat()
                }
            }
            
            response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                self.logger.error(f"Erro no heartbeat: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro ao enviar heartbeat: {e}")
            return False
    
    def send_metrics(self, metrics: Dict[str, Any]) -> bool:
        """Envia métricas para o servidor"""
        try:
            url = f"{self.server_url}/api/monitoring/metrics"
            data = {
                'api_key': self.api_key,
                'metrics': metrics,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                self.logger.error(f"Erro ao enviar métricas: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro ao enviar métricas: {e}")
            return False
    
    def get_pending_commands(self) -> list:
        """Obtém comandos pendentes do servidor"""
        try:
            url = f"{self.server_url}/api/commands/pending"
            data = {'api_key': self.api_key}
            
            response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Erro ao obter comandos: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Erro ao obter comandos: {e}")
            return []
    
    def update_command_status(self, command_id: int, status: str) -> bool:
        """Atualiza o status de um comando"""
        try:
            url = f"{self.server_url}/api/commands/{command_id}/status"
            data = {
                'api_key': self.api_key,
                'status': status
            }
            
            response = requests.put(url, json=data, timeout=10)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Erro ao atualizar status do comando: {e}")
            return False
    
    def submit_command_result(self, command_id: int, output: str, error_output: str, exit_code: int) -> bool:
        """Submete o resultado de um comando"""
        try:
            url = f"{self.server_url}/api/commands/{command_id}/result"
            data = {
                'api_key': self.api_key,
                'output': output,
                'error_output': error_output,
                'exit_code': exit_code,
                'status': 'completed' if exit_code == 0 else 'failed'
            }
            
            response = requests.post(url, json=data, timeout=10)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Erro ao submeter resultado do comando: {e}")
            return False
    
    def get_pending_transfers(self) -> list:
        """Obtém transferências de arquivo pendentes"""
        try:
            url = f"{self.server_url}/api/files/pending"
            data = {'api_key': self.api_key}
            
            response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                return []
                
        except Exception as e:
            self.logger.error(f"Erro ao obter transferências: {e}")
            return []
    
    def update_transfer_status(self, transfer_id: int, status: str, progress: float = 0, error_message: str = None) -> bool:
        """Atualiza o status de uma transferência"""
        try:
            url = f"{self.server_url}/api/files/transfers/{transfer_id}/status"
            data = {
                'api_key': self.api_key,
                'status': status,
                'progress': progress
            }
            
            if error_message:
                data['error_message'] = error_message
            
            response = requests.put(url, json=data, timeout=10)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Erro ao atualizar status da transferência: {e}")
            return False
    
    def heartbeat_worker(self):
        """Worker thread para heartbeat"""
        while self.running:
            self.send_heartbeat()
            time.sleep(self.heartbeat_interval)
    
    def metrics_worker(self):
        """Worker thread para coleta de métricas"""
        while self.running:
            try:
                metrics = self.collect_metrics()
                if metrics:
                    self.send_metrics(metrics)
            except Exception as e:
                self.logger.error(f"Erro na coleta de métricas: {e}")
            
            time.sleep(self.metrics_interval)
    
    def command_worker(self):
        """Worker thread para processamento de comandos"""
        while self.running:
            try:
                commands = self.get_pending_commands()
                for command in commands:
                    self.process_command(command)
            except Exception as e:
                self.logger.error(f"Erro no processamento de comandos: {e}")
            
            time.sleep(self.command_check_interval)
    
    def start(self):
        """Inicia o agente"""
        self.logger.info("Iniciando agente de monitoramento...")
        
        # Registra o dispositivo
        if not self.register_device():
            self.logger.error("Falha ao registrar dispositivo. Abortando.")
            return False
        
        self.running = True
        
        # Inicia threads
        self.heartbeat_thread = threading.Thread(target=self.heartbeat_worker, daemon=True)
        self.metrics_thread = threading.Thread(target=self.metrics_worker, daemon=True)
        self.command_thread = threading.Thread(target=self.command_worker, daemon=True)
        
        self.heartbeat_thread.start()
        self.metrics_thread.start()
        self.command_thread.start()
        
        self.logger.info("Agente iniciado com sucesso")
        return True
    
    def stop(self):
        """Para o agente"""
        self.logger.info("Parando agente...")
        self.running = False
        
        # Aguarda threads terminarem
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=5)
        if self.metrics_thread:
            self.metrics_thread.join(timeout=5)
        if self.command_thread:
            self.command_thread.join(timeout=5)
        
        self.logger.info("Agente parado")
    
    # Métodos abstratos que devem ser implementados pelas classes filhas
    def collect_metrics(self) -> Dict[str, Any]:
        """Coleta métricas do sistema (deve ser implementado pela classe filha)"""
        raise NotImplementedError
    
    def execute_command(self, command: str) -> tuple:
        """Executa um comando (deve ser implementado pela classe filha)"""
        raise NotImplementedError
    
    def process_command(self, command: Dict[str, Any]):
        """Processa um comando (deve ser implementado pela classe filha)"""
        raise NotImplementedError

