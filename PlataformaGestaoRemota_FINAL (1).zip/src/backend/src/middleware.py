"""
Middleware de Segurança
Plataforma de Gestão Remota de Infraestrutura

Este módulo implementa middlewares de segurança para Flask.
"""

import os
import time
from functools import wraps
from flask import request, jsonify, g
from .security import SecurityManager, RoleBasedAccessControl, InputValidator, AuditLogger, RateLimiter

# Instâncias globais
security_manager = SecurityManager(os.environ.get('SECRET_KEY', 'dev-secret-key'))
audit_logger = AuditLogger()
rate_limiter = RateLimiter()

def require_auth(f):
    """Decorator para exigir autenticação JWT"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        
        # Verifica header Authorization
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({'error': 'Token malformado'}), 401
        
        if not token:
            return jsonify({'error': 'Token de acesso requerido'}), 401
        
        # Verifica token
        payload = security_manager.verify_jwt_token(token)
        if not payload:
            return jsonify({'error': 'Token inválido ou expirado'}), 401
        
        # Adiciona dados do usuário ao contexto
        g.current_user = payload
        
        return f(*args, **kwargs)
    
    return decorated_function

def require_permission(permission):
    """Decorator para exigir permissão específica"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(g, 'current_user'):
                return jsonify({'error': 'Usuário não autenticado'}), 401
            
            user_role = g.current_user.get('role', 'viewer')
            
            if not RoleBasedAccessControl.has_permission(user_role, permission):
                audit_logger.log_event('ACCESS_DENIED', g.current_user['user_id'], {
                    'permission': permission,
                    'endpoint': request.endpoint,
                    'ip_address': request.remote_addr
                })
                return jsonify({'error': 'Permissão insuficiente'}), 403
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

def require_api_key(f):
    """Decorator para exigir chave API (para agentes)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.json.get('api_key') if request.json else None
        
        if not api_key:
            return jsonify({'error': 'Chave API requerida'}), 401
        
        # Aqui você validaria a API key no banco de dados
        # Por simplicidade, vamos assumir que é válida se não estiver vazia
        if len(api_key) < 10:
            return jsonify({'error': 'Chave API inválida'}), 401
        
        g.api_key = api_key
        return f(*args, **kwargs)
    
    return decorated_function

def rate_limit(endpoint_type='default'):
    """Decorator para rate limiting"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_ip = request.remote_addr
            
            if not rate_limiter.is_allowed(client_ip, endpoint_type):
                return jsonify({'error': 'Rate limit excedido'}), 429
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

def validate_input(f):
    """Decorator para validação de entrada"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.json:
            # Valida comandos se presente
            if 'command' in request.json:
                command = request.json['command']
                if not InputValidator.validate_command(command):
                    audit_logger.log_event('DANGEROUS_COMMAND_BLOCKED', 
                                         getattr(g, 'current_user', {}).get('user_id', 0), {
                        'command': command[:100],
                        'ip_address': request.remote_addr
                    })
                    return jsonify({'error': 'Comando não permitido por motivos de segurança'}), 400
                
                # Sanitiza o comando
                request.json['command'] = InputValidator.sanitize_input(command)
            
            # Valida caminhos de arquivo se presente
            if 'file_path' in request.json:
                file_path = request.json['file_path']
                if not InputValidator.validate_file_path(file_path):
                    return jsonify({'error': 'Caminho de arquivo não permitido'}), 400
                
                # Sanitiza o caminho
                request.json['file_path'] = InputValidator.sanitize_input(file_path)
        
        return f(*args, **kwargs)
    
    return decorated_function

def log_request(f):
    """Decorator para logging de requisições"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        
        # Executa a função
        result = f(*args, **kwargs)
        
        # Log da requisição
        duration = time.time() - start_time
        user_id = getattr(g, 'current_user', {}).get('user_id', 0)
        
        audit_logger.log_event('API_REQUEST', user_id, {
            'endpoint': request.endpoint,
            'method': request.method,
            'ip_address': request.remote_addr,
            'duration': round(duration, 3),
            'status_code': result[1] if isinstance(result, tuple) else 200
        })
        
        return result
    
    return decorated_function

def security_headers(response):
    """Adiciona headers de segurança às respostas"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

