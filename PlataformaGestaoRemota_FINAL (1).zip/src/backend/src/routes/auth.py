from flask import Blueprint, request, jsonify, g
from flask_cors import cross_origin
from src.models.user import db, User
from src.middleware import require_auth, rate_limit, log_request, security_manager, audit_logger, require_permission

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
@cross_origin()
@rate_limit('auth')
@log_request
def login():
    """User login endpoint with enhanced security"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400
        
        # Find user by username or email
        user = User.query.filter(
            (User.username == username) | (User.email == username)
        ).first()
        
        if not user or not user.check_password(password):
            # Log failed login attempt
            audit_logger.log_login_attempt(username, False, request.remote_addr)
            return jsonify({'error': 'Invalid credentials'}), 401
        
        if not user.is_active:
            audit_logger.log_login_attempt(username, False, request.remote_addr)
            return jsonify({'error': 'Account is disabled'}), 401
        
        # Update last login
        user.last_login = db.func.now()
        db.session.commit()
        
        # Generate secure JWT token
        token = security_manager.generate_jwt_token({
            'id': user.id,
            'username': user.username,
            'role': user.role
        })
        
        # Log successful login
        audit_logger.log_login_attempt(username, True, request.remote_addr)
        
        return jsonify({
            'token': token,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/register', methods=['POST'])
@cross_origin()
@rate_limit('auth')
@log_request
def register():
    """User registration endpoint with enhanced security"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        role = data.get('role', 'operator')
        
        if not username or not email or not password:
            return jsonify({'error': 'Username, email and password are required'}), 400
        
        # Validate role
        valid_roles = ['admin', 'operator', 'viewer']
        if role not in valid_roles:
            role = 'operator'
        
        # Check if user already exists
        if User.query.filter((User.username == username) | (User.email == email)).first():
            return jsonify({'error': 'User already exists'}), 409
        
        # Create new user with secure password hashing
        user = User(
            username=username,
            email=email,
            role=role
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Log user registration
        audit_logger.log_event('USER_REGISTERED', user.id, {
            'username': username,
            'role': role,
            'ip_address': request.remote_addr
        })
        
        return jsonify({
            'message': 'User created successfully',
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/verify', methods=['POST'])
@cross_origin()
@log_request
def verify():
    """Verify JWT token"""
    try:
        data = request.get_json()
        token = data.get('token')
        
        if not token:
            return jsonify({'error': 'Token is required'}), 400
        
        payload = security_manager.verify_jwt_token(token)
        if not payload:
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        # Get fresh user data
        user = User.query.get(payload['user_id'])
        if not user or not user.is_active:
            return jsonify({'error': 'User not found or inactive'}), 401
        
        return jsonify({
            'valid': True,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/logout', methods=['POST'])
@cross_origin()
@require_auth
@log_request
def logout():
    """User logout endpoint"""
    try:
        # Log logout event
        audit_logger.log_event('USER_LOGOUT', g.current_user['user_id'], {
            'ip_address': request.remote_addr
        })
        
        return jsonify({'message': 'Logged out successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/users', methods=['GET'])
@cross_origin()
@require_auth
@require_permission('manage_users')
@log_request
def get_users():
    """Get all users (admin only)"""
    try:
        users = User.query.all()
        return jsonify([user.to_dict() for user in users]), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/profile', methods=['GET'])
@cross_origin()
@require_auth
@log_request
def get_profile():
    """Get current user profile"""
    try:
        user_id = g.current_user['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({'user': user.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/change-password', methods=['POST'])
@cross_origin()
@require_auth
@rate_limit('auth')
@log_request
def change_password():
    """Change user password"""
    try:
        data = request.get_json()
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not current_password or not new_password:
            return jsonify({'error': 'Current and new password are required'}), 400
        
        user_id = g.current_user['user_id']
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Verify current password
        if not user.check_password(current_password):
            return jsonify({'error': 'Current password is incorrect'}), 401
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        # Log password change
        audit_logger.log_event('PASSWORD_CHANGED', user.id, {
            'ip_address': request.remote_addr
        })
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

