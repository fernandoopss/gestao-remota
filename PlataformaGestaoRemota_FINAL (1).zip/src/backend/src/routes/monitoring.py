from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from datetime import datetime, timedelta
from src.models.user import db, Device
import json

monitoring_bp = Blueprint('monitoring', __name__)

# In-memory storage for monitoring data (in production, use InfluxDB)
monitoring_data = {}

@monitoring_bp.route('/metrics', methods=['POST'])
@cross_origin()
def receive_metrics():
    """Receive monitoring metrics from agents"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        metrics = data.get('metrics', {})
        timestamp = data.get('timestamp', datetime.utcnow().isoformat())
        
        if not api_key:
            return jsonify({'error': 'API key is required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        # Store metrics (in production, this would go to InfluxDB)
        device_id = str(device.id)
        if device_id not in monitoring_data:
            monitoring_data[device_id] = []
        
        # Keep only last 1000 data points per device
        if len(monitoring_data[device_id]) >= 1000:
            monitoring_data[device_id] = monitoring_data[device_id][-999:]
        
        monitoring_data[device_id].append({
            'timestamp': timestamp,
            'cpu_percent': metrics.get('cpu_percent', 0),
            'memory_percent': metrics.get('memory_percent', 0),
            'memory_used': metrics.get('memory_used', 0),
            'memory_total': metrics.get('memory_total', 0),
            'disk_percent': metrics.get('disk_percent', 0),
            'disk_used': metrics.get('disk_used', 0),
            'disk_total': metrics.get('disk_total', 0),
            'network_bytes_sent': metrics.get('network_bytes_sent', 0),
            'network_bytes_recv': metrics.get('network_bytes_recv', 0),
            'uptime': metrics.get('uptime', 0)
        })
        
        # Update device last seen
        device.last_seen = datetime.utcnow()
        device.status = 'online'
        db.session.commit()
        
        return jsonify({'message': 'Metrics received successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@monitoring_bp.route('/devices/<int:device_id>/metrics', methods=['GET'])
@cross_origin()
def get_device_metrics(device_id):
    """Get monitoring metrics for a specific device"""
    try:
        device = Device.query.get_or_404(device_id)
        
        # Get query parameters
        limit = request.args.get('limit', 100, type=int)
        hours = request.args.get('hours', 24, type=int)
        
        device_id_str = str(device_id)
        if device_id_str not in monitoring_data:
            return jsonify([]), 200
        
        # Filter by time range
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        filtered_data = []
        
        for metric in monitoring_data[device_id_str]:
            metric_time = datetime.fromisoformat(metric['timestamp'].replace('Z', '+00:00'))
            if metric_time >= cutoff_time:
                filtered_data.append(metric)
        
        # Apply limit
        if len(filtered_data) > limit:
            filtered_data = filtered_data[-limit:]
        
        return jsonify(filtered_data), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@monitoring_bp.route('/devices/<int:device_id>/metrics/latest', methods=['GET'])
@cross_origin()
def get_latest_metrics(device_id):
    """Get latest metrics for a specific device"""
    try:
        device = Device.query.get_or_404(device_id)
        
        device_id_str = str(device_id)
        if device_id_str not in monitoring_data or not monitoring_data[device_id_str]:
            return jsonify({}), 200
        
        latest_metric = monitoring_data[device_id_str][-1]
        return jsonify(latest_metric), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@monitoring_bp.route('/overview', methods=['GET'])
@cross_origin()
def get_monitoring_overview():
    """Get monitoring overview for all devices"""
    try:
        devices = Device.query.all()
        overview = []
        
        for device in devices:
            device_id_str = str(device.id)
            latest_metrics = {}
            
            if device_id_str in monitoring_data and monitoring_data[device_id_str]:
                latest_metrics = monitoring_data[device_id_str][-1]
            
            overview.append({
                'device': device.to_dict(),
                'latest_metrics': latest_metrics
            })
        
        return jsonify(overview), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@monitoring_bp.route('/alerts', methods=['GET'])
@cross_origin()
def get_alerts():
    """Get current alerts based on thresholds"""
    try:
        alerts = []
        devices = Device.query.all()
        
        # Define thresholds
        cpu_threshold = 80
        memory_threshold = 85
        disk_threshold = 90
        
        for device in devices:
            device_id_str = str(device.id)
            
            if device_id_str in monitoring_data and monitoring_data[device_id_str]:
                latest_metrics = monitoring_data[device_id_str][-1]
                
                # Check CPU threshold
                if latest_metrics.get('cpu_percent', 0) > cpu_threshold:
                    alerts.append({
                        'device_id': device.id,
                        'device_name': device.name,
                        'type': 'cpu',
                        'severity': 'warning',
                        'message': f'High CPU usage: {latest_metrics["cpu_percent"]:.1f}%',
                        'value': latest_metrics['cpu_percent'],
                        'threshold': cpu_threshold,
                        'timestamp': latest_metrics['timestamp']
                    })
                
                # Check Memory threshold
                if latest_metrics.get('memory_percent', 0) > memory_threshold:
                    alerts.append({
                        'device_id': device.id,
                        'device_name': device.name,
                        'type': 'memory',
                        'severity': 'warning',
                        'message': f'High memory usage: {latest_metrics["memory_percent"]:.1f}%',
                        'value': latest_metrics['memory_percent'],
                        'threshold': memory_threshold,
                        'timestamp': latest_metrics['timestamp']
                    })
                
                # Check Disk threshold
                if latest_metrics.get('disk_percent', 0) > disk_threshold:
                    alerts.append({
                        'device_id': device.id,
                        'device_name': device.name,
                        'type': 'disk',
                        'severity': 'critical',
                        'message': f'High disk usage: {latest_metrics["disk_percent"]:.1f}%',
                        'value': latest_metrics['disk_percent'],
                        'threshold': disk_threshold,
                        'timestamp': latest_metrics['timestamp']
                    })
            
            # Check if device is offline
            if device.last_seen:
                time_diff = datetime.utcnow() - device.last_seen
                if time_diff > timedelta(minutes=5):  # 5 minutes offline threshold
                    alerts.append({
                        'device_id': device.id,
                        'device_name': device.name,
                        'type': 'connectivity',
                        'severity': 'critical',
                        'message': f'Device offline for {time_diff}',
                        'timestamp': device.last_seen.isoformat()
                    })
        
        return jsonify(alerts), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@monitoring_bp.route('/devices/<int:device_id>/status', methods=['GET'])
@cross_origin()
def get_device_status(device_id):
    """Get comprehensive status for a specific device"""
    try:
        device = Device.query.get_or_404(device_id)
        
        device_id_str = str(device_id)
        latest_metrics = {}
        metrics_history = []
        
        if device_id_str in monitoring_data:
            if monitoring_data[device_id_str]:
                latest_metrics = monitoring_data[device_id_str][-1]
            metrics_history = monitoring_data[device_id_str][-10:]  # Last 10 data points
        
        # Calculate uptime
        uptime_seconds = latest_metrics.get('uptime', 0)
        uptime_hours = uptime_seconds / 3600 if uptime_seconds else 0
        
        status = {
            'device': device.to_dict(),
            'latest_metrics': latest_metrics,
            'metrics_history': metrics_history,
            'uptime_hours': uptime_hours,
            'is_online': device.status == 'online' and device.last_seen and 
                        (datetime.utcnow() - device.last_seen) < timedelta(minutes=5)
        }
        
        return jsonify(status), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

