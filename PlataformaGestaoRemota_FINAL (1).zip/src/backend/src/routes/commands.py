from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from datetime import datetime
from src.models.user import db, Device, Command, User
import uuid

commands_bp = Blueprint('commands', __name__)

# In-memory storage for pending commands (in production, use Redis or message queue)
pending_commands = {}

@commands_bp.route('/', methods=['POST'])
@cross_origin()
def create_command():
    """Create a new command to be executed on a device"""
    try:
        data = request.get_json()
        device_id = data.get('device_id')
        command_text = data.get('command')
        user_id = data.get('user_id', 1)  # In production, get from JWT token
        
        if not device_id or not command_text:
            return jsonify({'error': 'Device ID and command are required'}), 400
        
        device = Device.query.get_or_404(device_id)
        user = User.query.get_or_404(user_id)
        
        # Create command record
        command = Command(
            device_id=device_id,
            user_id=user_id,
            command=command_text,
            status='pending'
        )
        
        db.session.add(command)
        db.session.commit()
        
        # Add to pending commands queue for the device
        device_key = str(device_id)
        if device_key not in pending_commands:
            pending_commands[device_key] = []
        
        pending_commands[device_key].append({
            'command_id': command.id,
            'command': command_text,
            'created_at': command.created_at.isoformat()
        })
        
        return jsonify({
            'message': 'Command created successfully',
            'command': command.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/<int:command_id>', methods=['GET'])
@cross_origin()
def get_command(command_id):
    """Get specific command by ID"""
    try:
        command = Command.query.get_or_404(command_id)
        return jsonify(command.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/device/<int:device_id>', methods=['GET'])
@cross_origin()
def get_device_commands(device_id):
    """Get all commands for a specific device"""
    try:
        device = Device.query.get_or_404(device_id)
        
        # Get query parameters
        limit = request.args.get('limit', 50, type=int)
        status = request.args.get('status')
        
        query = Command.query.filter_by(device_id=device_id)
        
        if status:
            query = query.filter_by(status=status)
        
        commands = query.order_by(Command.created_at.desc()).limit(limit).all()
        
        return jsonify([command.to_dict() for command in commands]), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/pending', methods=['POST'])
@cross_origin()
def get_pending_commands():
    """Get pending commands for a device (called by agent)"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        
        if not api_key:
            return jsonify({'error': 'API key is required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        device_key = str(device.id)
        commands = pending_commands.get(device_key, [])
        
        # Update device last seen
        device.last_seen = datetime.utcnow()
        db.session.commit()
        
        return jsonify(commands), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/<int:command_id>/result', methods=['POST'])
@cross_origin()
def submit_command_result():
    """Submit command execution result (called by agent)"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        output = data.get('output', '')
        error_output = data.get('error_output', '')
        exit_code = data.get('exit_code', 0)
        status = data.get('status', 'completed')
        
        if not api_key:
            return jsonify({'error': 'API key is required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        command_id = request.view_args['command_id']
        command = Command.query.get_or_404(command_id)
        
        # Verify command belongs to this device
        if command.device_id != device.id:
            return jsonify({'error': 'Command does not belong to this device'}), 403
        
        # Update command with results
        command.output = output
        command.error_output = error_output
        command.exit_code = exit_code
        command.status = status
        command.completed_at = datetime.utcnow()
        
        if command.status == 'pending':
            command.started_at = datetime.utcnow()
        
        db.session.commit()
        
        # Remove from pending commands
        device_key = str(device.id)
        if device_key in pending_commands:
            pending_commands[device_key] = [
                cmd for cmd in pending_commands[device_key] 
                if cmd['command_id'] != command_id
            ]
        
        return jsonify({
            'message': 'Command result submitted successfully',
            'command': command.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/<int:command_id>/status', methods=['PUT'])
@cross_origin()
def update_command_status():
    """Update command status (called by agent)"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        status = data.get('status')
        
        if not api_key or not status:
            return jsonify({'error': 'API key and status are required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        command_id = request.view_args['command_id']
        command = Command.query.get_or_404(command_id)
        
        # Verify command belongs to this device
        if command.device_id != device.id:
            return jsonify({'error': 'Command does not belong to this device'}), 403
        
        # Update command status
        command.status = status
        
        if status == 'running' and not command.started_at:
            command.started_at = datetime.utcnow()
        elif status in ['completed', 'failed'] and not command.completed_at:
            command.completed_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Command status updated successfully',
            'command': command.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/history', methods=['GET'])
@cross_origin()
def get_command_history():
    """Get command history for all devices"""
    try:
        # Get query parameters
        limit = request.args.get('limit', 100, type=int)
        device_id = request.args.get('device_id', type=int)
        user_id = request.args.get('user_id', type=int)
        status = request.args.get('status')
        
        query = Command.query
        
        if device_id:
            query = query.filter_by(device_id=device_id)
        if user_id:
            query = query.filter_by(user_id=user_id)
        if status:
            query = query.filter_by(status=status)
        
        commands = query.order_by(Command.created_at.desc()).limit(limit).all()
        
        return jsonify([command.to_dict() for command in commands]), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@commands_bp.route('/<int:command_id>', methods=['DELETE'])
@cross_origin()
def delete_command(command_id):
    """Delete a command (only if pending)"""
    try:
        command = Command.query.get_or_404(command_id)
        
        if command.status != 'pending':
            return jsonify({'error': 'Can only delete pending commands'}), 400
        
        # Remove from pending commands
        device_key = str(command.device_id)
        if device_key in pending_commands:
            pending_commands[device_key] = [
                cmd for cmd in pending_commands[device_key] 
                if cmd['command_id'] != command_id
            ]
        
        db.session.delete(command)
        db.session.commit()
        
        return jsonify({'message': 'Command deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

