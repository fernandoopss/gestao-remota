from flask import Blueprint, request, jsonify, g
from flask_cors import cross_origin
from src.models.user import db, Device
from src.middleware import require_api_key, require_auth, require_permission, validate_input, log_request, audit_logger
import secrets
from datetime import datetime

devices_bp = Blueprint('devices', __name__)

@devices_bp.route('/register', methods=['POST'])
@cross_origin()
@validate_input
@log_request
def register_device():
    """Register a new device with enhanced security"""
    try:
        data = request.get_json()
        
        required_fields = ['name', 'hostname', 'ip_address', 'operating_system']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if device already exists
        existing_device = Device.query.filter_by(hostname=data['hostname']).first()
        if existing_device:
            # Update existing device info
            existing_device.name = data['name']
            existing_device.ip_address = data['ip_address']
            existing_device.operating_system = data['operating_system']
            existing_device.os_version = data.get('os_version', '')
            existing_device.agent_version = data.get('agent_version', '1.0.0')
            existing_device.last_seen = datetime.utcnow()
            existing_device.status = 'online'
            
            db.session.commit()
            
            return jsonify({
                'message': 'Device updated successfully',
                'device': existing_device.to_dict(),
                'api_key': existing_device.api_key
            }), 200
        
        # Generate secure API key
        api_key = secrets.token_urlsafe(32)
        
        # Create new device
        device = Device(
            name=data['name'],
            hostname=data['hostname'],
            ip_address=data['ip_address'],
            operating_system=data['operating_system'],
            os_version=data.get('os_version', ''),
            agent_version=data.get('agent_version', '1.0.0'),
            api_key=api_key,
            status='online'
        )
        
        db.session.add(device)
        db.session.commit()
        
        # Log device registration
        audit_logger.log_event('DEVICE_REGISTERED', 0, {
            'device_id': device.id,
            'device_name': device.name,
            'hostname': device.hostname,
            'ip_address': device.ip_address,
            'operating_system': device.operating_system
        })
        
        return jsonify({
            'message': 'Device registered successfully',
            'device': device.to_dict(),
            'api_key': api_key
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@devices_bp.route('/heartbeat', methods=['POST'])
@cross_origin()
@require_api_key
@log_request
def device_heartbeat():
    """Update device heartbeat with API key validation"""
    try:
        api_key = g.api_key
        
        # Find device by API key
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Device not found'}), 404
        
        # Update last seen and status
        device.last_seen = datetime.utcnow()
        device.status = 'online'
        
        # Update additional status info if provided
        data = request.get_json()
        if data and 'status' in data:
            status_info = data['status']
            if 'agent_version' in status_info:
                device.agent_version = status_info['agent_version']
        
        db.session.commit()
        
        return jsonify({'message': 'Heartbeat received'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@devices_bp.route('/', methods=['GET'])
@cross_origin()
@require_auth
@require_permission('view_all_devices')
@log_request
def list_devices():
    """List all devices with role-based access"""
    try:
        devices = Device.query.all()
        
        # Update offline status for devices not seen recently
        from datetime import timedelta
        offline_threshold = datetime.utcnow() - timedelta(minutes=5)
        
        for device in devices:
            if device.last_seen and device.last_seen < offline_threshold:
                device.status = 'offline'
        
        db.session.commit()
        
        return jsonify([device.to_dict() for device in devices]), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@devices_bp.route('/<int:device_id>', methods=['GET'])
@cross_origin()
@require_auth
@require_permission('view_all_devices')
@log_request
def get_device(device_id):
    """Get specific device details"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'error': 'Device not found'}), 404
        
        return jsonify(device.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@devices_bp.route('/<int:device_id>', methods=['PUT'])
@cross_origin()
@require_auth
@require_permission('manage_devices')
@validate_input
@log_request
def update_device(device_id):
    """Update device information with audit logging"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'error': 'Device not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        if 'name' in data:
            device.name = data['name']
        if 'group' in data:
            device.group = data['group']
        
        db.session.commit()
        
        # Log device update
        audit_logger.log_event('DEVICE_UPDATED', g.current_user['user_id'], {
            'device_id': device.id,
            'device_name': device.name,
            'changes': data
        })
        
        return jsonify({
            'message': 'Device updated successfully',
            'device': device.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@devices_bp.route('/<int:device_id>', methods=['DELETE'])
@cross_origin()
@require_auth
@require_permission('manage_devices')
@log_request
def delete_device(device_id):
    """Delete a device with audit logging"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'error': 'Device not found'}), 404
        
        device_name = device.name
        
        # Log device deletion before removing
        audit_logger.log_event('DEVICE_DELETED', g.current_user['user_id'], {
            'device_id': device.id,
            'device_name': device_name,
            'hostname': device.hostname
        })
        
        db.session.delete(device)
        db.session.commit()
        
        return jsonify({'message': 'Device deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

