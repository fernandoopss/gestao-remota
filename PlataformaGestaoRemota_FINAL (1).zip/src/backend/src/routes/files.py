from flask import Blueprint, request, jsonify, send_file
from flask_cors import cross_origin
from datetime import datetime
from src.models.user import db, Device, FileTransfer, User
import os
import uuid
from werkzeug.utils import secure_filename

files_bp = Blueprint('files', __name__)

# Configuration
UPLOAD_FOLDER = '/tmp/file_transfers'
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@files_bp.route('/upload', methods=['POST'])
@cross_origin()
def upload_file():
    """Upload a file to be transferred to a device"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        device_id = request.form.get('device_id')
        user_id = request.form.get('user_id', 1)  # In production, get from JWT token
        target_path = request.form.get('target_path', '')
        
        if not device_id:
            return jsonify({'error': 'Device ID is required'}), 400
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        device = Device.query.get_or_404(device_id)
        user = User.query.get_or_404(user_id)
        
        # Secure filename
        filename = secure_filename(file.filename)
        if not filename:
            filename = f"upload_{uuid.uuid4().hex[:8]}"
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({'error': f'File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB'}), 400
        
        # Save file temporarily
        temp_filename = f"{uuid.uuid4().hex}_{filename}"
        temp_path = os.path.join(UPLOAD_FOLDER, temp_filename)
        file.save(temp_path)
        
        # Create file transfer record
        file_transfer = FileTransfer(
            device_id=device_id,
            user_id=user_id,
            filename=filename,
            file_path=target_path or f"/tmp/{filename}",
            file_size=file_size,
            operation_type='upload',
            status='pending'
        )
        
        db.session.add(file_transfer)
        db.session.commit()
        
        return jsonify({
            'message': 'File uploaded successfully',
            'transfer': file_transfer.to_dict(),
            'temp_path': temp_path
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@files_bp.route('/download/<int:transfer_id>', methods=['GET'])
@cross_origin()
def download_file(transfer_id):
    """Download a file from a completed transfer"""
    try:
        file_transfer = FileTransfer.query.get_or_404(transfer_id)
        
        if file_transfer.operation_type != 'download':
            return jsonify({'error': 'This is not a download transfer'}), 400
        
        if file_transfer.status != 'completed':
            return jsonify({'error': 'Transfer not completed'}), 400
        
        # In a real implementation, the file would be stored securely
        # For now, return the transfer information
        return jsonify({
            'message': 'File ready for download',
            'transfer': file_transfer.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/request-download', methods=['POST'])
@cross_origin()
def request_download():
    """Request a file download from a device"""
    try:
        data = request.get_json()
        device_id = data.get('device_id')
        file_path = data.get('file_path')
        user_id = data.get('user_id', 1)  # In production, get from JWT token
        
        if not device_id or not file_path:
            return jsonify({'error': 'Device ID and file path are required'}), 400
        
        device = Device.query.get_or_404(device_id)
        user = User.query.get_or_404(user_id)
        
        # Extract filename from path
        filename = os.path.basename(file_path)
        
        # Create file transfer record
        file_transfer = FileTransfer(
            device_id=device_id,
            user_id=user_id,
            filename=filename,
            file_path=file_path,
            operation_type='download',
            status='pending'
        )
        
        db.session.add(file_transfer)
        db.session.commit()
        
        return jsonify({
            'message': 'Download request created successfully',
            'transfer': file_transfer.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@files_bp.route('/transfers', methods=['GET'])
@cross_origin()
def get_transfers():
    """Get file transfer history"""
    try:
        # Get query parameters
        limit = request.args.get('limit', 50, type=int)
        device_id = request.args.get('device_id', type=int)
        operation_type = request.args.get('type')
        status = request.args.get('status')
        
        query = FileTransfer.query
        
        if device_id:
            query = query.filter_by(device_id=device_id)
        if operation_type:
            query = query.filter_by(operation_type=operation_type)
        if status:
            query = query.filter_by(status=status)
        
        transfers = query.order_by(FileTransfer.created_at.desc()).limit(limit).all()
        
        return jsonify([transfer.to_dict() for transfer in transfers]), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/transfers/<int:transfer_id>', methods=['GET'])
@cross_origin()
def get_transfer(transfer_id):
    """Get specific file transfer by ID"""
    try:
        transfer = FileTransfer.query.get_or_404(transfer_id)
        return jsonify(transfer.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/pending', methods=['POST'])
@cross_origin()
def get_pending_transfers():
    """Get pending file transfers for a device (called by agent)"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        
        if not api_key:
            return jsonify({'error': 'API key is required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        # Get pending transfers for this device
        transfers = FileTransfer.query.filter_by(
            device_id=device.id,
            status='pending'
        ).all()
        
        # Update device last seen
        device.last_seen = datetime.utcnow()
        db.session.commit()
        
        return jsonify([transfer.to_dict() for transfer in transfers]), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/transfers/<int:transfer_id>/status', methods=['PUT'])
@cross_origin()
def update_transfer_status():
    """Update file transfer status (called by agent)"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        status = data.get('status')
        progress = data.get('progress', 0)
        error_message = data.get('error_message')
        
        if not api_key or not status:
            return jsonify({'error': 'API key and status are required'}), 400
        
        device = Device.query.filter_by(api_key=api_key).first()
        if not device:
            return jsonify({'error': 'Invalid API key'}), 401
        
        transfer_id = request.view_args['transfer_id']
        transfer = FileTransfer.query.get_or_404(transfer_id)
        
        # Verify transfer belongs to this device
        if transfer.device_id != device.id:
            return jsonify({'error': 'Transfer does not belong to this device'}), 403
        
        # Update transfer
        transfer.status = status
        transfer.progress = progress
        
        if error_message:
            transfer.error_message = error_message
        
        if status == 'in_progress' and not transfer.started_at:
            transfer.started_at = datetime.utcnow()
        elif status in ['completed', 'failed'] and not transfer.completed_at:
            transfer.completed_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Transfer status updated successfully',
            'transfer': transfer.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@files_bp.route('/transfers/<int:transfer_id>', methods=['DELETE'])
@cross_origin()
def delete_transfer(transfer_id):
    """Delete a file transfer (only if pending or failed)"""
    try:
        transfer = FileTransfer.query.get_or_404(transfer_id)
        
        if transfer.status not in ['pending', 'failed']:
            return jsonify({'error': 'Can only delete pending or failed transfers'}), 400
        
        db.session.delete(transfer)
        db.session.commit()
        
        return jsonify({'message': 'Transfer deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@files_bp.route('/device/<int:device_id>/files', methods=['POST'])
@cross_origin()
def list_device_files():
    """Request file listing from device (to be implemented by agent)"""
    try:
        data = request.get_json()
        path = data.get('path', '/')
        
        device = Device.query.get_or_404(device_id)
        
        # This would typically create a command to list files
        # For now, return a placeholder response
        return jsonify({
            'message': 'File listing request sent to device',
            'path': path,
            'device_id': device_id
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

