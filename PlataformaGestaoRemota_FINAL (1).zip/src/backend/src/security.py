#!/usr/bin/env python3
"""
Módulo de Segurança
Plataforma de Gestão Remota de Infraestrutura

Este módulo implementa funcionalidades de segurança avançadas para a plataforma.
"""

import os
import jwt
import bcrypt
import secrets
import hashlib
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import base64
from typing import Dict, Any, Optional

class SecurityManager:
    """Gerenciador de segurança da plataforma"""
    
    def __init__(self, secret_key: str):
        self.secret_key = secret_key
        self.jwt_algorithm = 'HS256'
        self.jwt_expiration_hours = 24
        
    def generate_api_key(self) -> str:
        """Gera uma chave API segura"""
        return secrets.token_urlsafe(32)
    
    def hash_password(self, password: str) -> str:
        """Gera hash seguro da senha"""
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verifica se a senha corresponde ao hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def generate_jwt_token(self, user_data: Dict[str, Any]) -> str:
        """Gera token JWT para autenticação"""
        payload = {
            'user_id': user_data['id'],
            'username': user_data['username'],
            'role': user_data.get('role', 'user'),
            'exp': datetime.utcnow() + timedelta(hours=self.jwt_expiration_hours),
            'iat': datetime.utcnow(),
            'jti': secrets.token_urlsafe(16)  # JWT ID único
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.jwt_algorithm)
    
    def verify_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verifica e decodifica token JWT"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.jwt_algorithm])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def generate_encryption_key(self, password: str, salt: bytes = None) -> bytes:
        """Gera chave de criptografia a partir de senha"""
        if salt is None:
            salt = os.urandom(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return key, salt
    
    def encrypt_data(self, data: str, key: bytes) -> str:
        """Criptografa dados usando Fernet"""
        f = Fernet(key)
        encrypted_data = f.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted_data).decode()
    
    def decrypt_data(self, encrypted_data: str, key: bytes) -> str:
        """Descriptografa dados usando Fernet"""
        f = Fernet(key)
        decoded_data = base64.urlsafe_b64decode(encrypted_data.encode())
        decrypted_data = f.decrypt(decoded_data)
        return decrypted_data.decode()
    
    def generate_command_signature(self, command: str, api_key: str) -> str:
        """Gera assinatura para validação de integridade de comandos"""
        message = f"{command}:{api_key}:{datetime.utcnow().isoformat()}"
        signature = hashlib.sha256(message.encode()).hexdigest()
        return signature
    
    def verify_command_signature(self, command: str, api_key: str, signature: str, timestamp: str, max_age_minutes: int = 5) -> bool:
        """Verifica assinatura de comando"""
        try:
            # Verifica se o timestamp não é muito antigo
            cmd_time = datetime.fromisoformat(timestamp)
            if datetime.utcnow() - cmd_time > timedelta(minutes=max_age_minutes):
                return False
            
            # Verifica a assinatura
            expected_message = f"{command}:{api_key}:{timestamp}"
            expected_signature = hashlib.sha256(expected_message.encode()).hexdigest()
            
            return secrets.compare_digest(signature, expected_signature)
        except Exception:
            return False

class RoleBasedAccessControl:
    """Sistema de controle de acesso baseado em papéis"""
    
    ROLES = {
        'admin': {
            'permissions': [
                'view_all_devices',
                'manage_devices',
                'execute_commands',
                'transfer_files',
                'manage_users',
                'view_logs',
                'manage_system'
            ]
        },
        'operator': {
            'permissions': [
                'view_assigned_devices',
                'execute_commands',
                'transfer_files',
                'view_logs'
            ]
        },
        'viewer': {
            'permissions': [
                'view_assigned_devices',
                'view_logs'
            ]
        }
    }
    
    @classmethod
    def has_permission(cls, user_role: str, permission: str) -> bool:
        """Verifica se o usuário tem a permissão especificada"""
        role_data = cls.ROLES.get(user_role, {})
        permissions = role_data.get('permissions', [])
        return permission in permissions
    
    @classmethod
    def get_user_permissions(cls, user_role: str) -> list:
        """Retorna todas as permissões do usuário"""
        role_data = cls.ROLES.get(user_role, {})
        return role_data.get('permissions', [])

class InputValidator:
    """Validador de entrada para prevenir ataques"""
    
    @staticmethod
    def validate_command(command: str) -> bool:
        """Valida comando para prevenir injeção"""
        if not command or len(command.strip()) == 0:
            return False
        
        # Lista de comandos perigosos (pode ser expandida)
        dangerous_patterns = [
            'rm -rf /',
            'format c:',
            'del /f /s /q',
            'shutdown',
            'reboot',
            'halt',
            'poweroff',
            'mkfs',
            'fdisk',
            'dd if=',
            '> /dev/sda',
            'chmod 777 /',
            'chown root:root /',
        ]
        
        command_lower = command.lower()
        for pattern in dangerous_patterns:
            if pattern in command_lower:
                return False
        
        return True
    
    @staticmethod
    def validate_file_path(file_path: str) -> bool:
        """Valida caminho de arquivo para prevenir path traversal"""
        if not file_path:
            return False
        
        # Previne path traversal
        if '..' in file_path or file_path.startswith('/'):
            return False
        
        # Previne acesso a arquivos sensíveis
        sensitive_paths = [
            '/etc/passwd',
            '/etc/shadow',
            '/etc/hosts',
            'c:\\windows\\system32',
            'c:\\windows\\syswow64',
            '/boot/',
            '/sys/',
            '/proc/'
        ]
        
        file_path_lower = file_path.lower()
        for sensitive in sensitive_paths:
            if sensitive in file_path_lower:
                return False
        
        return True
    
    @staticmethod
    def sanitize_input(input_str: str, max_length: int = 1000) -> str:
        """Sanitiza entrada do usuário"""
        if not input_str:
            return ""
        
        # Remove caracteres de controle
        sanitized = ''.join(char for char in input_str if ord(char) >= 32 or char in '\n\r\t')
        
        # Limita o tamanho
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length]
        
        return sanitized.strip()

class AuditLogger:
    """Sistema de auditoria e logs de segurança"""
    
    def __init__(self, log_file: str = None):
        if log_file is None:
            # Use a local log file if no path is specified
            log_file = os.path.join(os.path.dirname(__file__), '..', 'logs', 'audit.log')
        
        self.log_file = log_file
        self._ensure_log_directory()
    
    def _ensure_log_directory(self):
        """Garante que o diretório de logs existe"""
        log_dir = os.path.dirname(self.log_file)
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, mode=0o750, exist_ok=True)
    
    def log_event(self, event_type: str, user_id: int, details: Dict[str, Any]):
        """Registra evento de auditoria"""
        timestamp = datetime.utcnow().isoformat()
        
        log_entry = {
            'timestamp': timestamp,
            'event_type': event_type,
            'user_id': user_id,
            'details': details
        }
        
        try:
            with open(self.log_file, 'a') as f:
                f.write(f"{timestamp} - {event_type} - User:{user_id} - {details}\n")
        except Exception as e:
            print(f"Erro ao escrever log de auditoria: {e}")
    
    def log_login_attempt(self, username: str, success: bool, ip_address: str):
        """Registra tentativa de login"""
        self.log_event('LOGIN_ATTEMPT', 0, {
            'username': username,
            'success': success,
            'ip_address': ip_address
        })
    
    def log_command_execution(self, user_id: int, device_id: int, command: str, success: bool):
        """Registra execução de comando"""
        self.log_event('COMMAND_EXECUTION', user_id, {
            'device_id': device_id,
            'command': command[:100],  # Limita tamanho do comando no log
            'success': success
        })
    
    def log_file_transfer(self, user_id: int, device_id: int, operation: str, file_path: str, success: bool):
        """Registra transferência de arquivo"""
        self.log_event('FILE_TRANSFER', user_id, {
            'device_id': device_id,
            'operation': operation,
            'file_path': file_path,
            'success': success
        })

class RateLimiter:
    """Sistema de rate limiting para APIs"""
    
    def __init__(self):
        self.requests = {}  # {ip: [(timestamp, endpoint), ...]}
        self.limits = {
            'default': {'requests': 100, 'window': 3600},  # 100 requests per hour
            'auth': {'requests': 10, 'window': 300},        # 10 auth attempts per 5 minutes
            'commands': {'requests': 50, 'window': 3600},   # 50 commands per hour
        }
    
    def is_allowed(self, ip_address: str, endpoint_type: str = 'default') -> bool:
        """Verifica se a requisição é permitida"""
        now = datetime.utcnow()
        limit_config = self.limits.get(endpoint_type, self.limits['default'])
        
        # Limpa requisições antigas
        if ip_address in self.requests:
            cutoff_time = now - timedelta(seconds=limit_config['window'])
            self.requests[ip_address] = [
                (timestamp, ep) for timestamp, ep in self.requests[ip_address]
                if timestamp > cutoff_time and ep == endpoint_type
            ]
        else:
            self.requests[ip_address] = []
        
        # Verifica limite
        current_requests = len([
            req for req in self.requests[ip_address]
            if req[1] == endpoint_type
        ])
        
        if current_requests >= limit_config['requests']:
            return False
        
        # Adiciona nova requisição
        self.requests[ip_address].append((now, endpoint_type))
        return True

