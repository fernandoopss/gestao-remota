import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Server, 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Cpu, 
  HardDrive, 
  MemoryStick,
  TrendingUp
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const Dashboard = () => {
  const [overview, setOverview] = useState([])
  const [alerts, setAlerts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchOverview()
    fetchAlerts()
    
    // Refresh data every 30 seconds
    const interval = setInterval(() => {
      fetchOverview()
      fetchAlerts()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const fetchOverview = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/monitoring/overview')
      const data = await response.json()
      setOverview(data)
    } catch (error) {
      console.error('Error fetching overview:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAlerts = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/monitoring/alerts')
      const data = await response.json()
      setAlerts(data)
    } catch (error) {
      console.error('Error fetching alerts:', error)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-500'
      case 'offline': return 'bg-red-500'
      case 'error': return 'bg-yellow-500'
      default: return 'bg-gray-500'
    }
  }

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'destructive'
      case 'warning': return 'secondary'
      default: return 'outline'
    }
  }

  // Calculate statistics
  const totalDevices = overview.length
  const onlineDevices = overview.filter(item => item.device.status === 'online').length
  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical').length
  const avgCpuUsage = overview.length > 0 
    ? overview.reduce((sum, item) => sum + (item.latest_metrics?.cpu_percent || 0), 0) / overview.length 
    : 0

  // Sample data for charts
  const chartData = [
    { time: '00:00', cpu: 45, memory: 60, disk: 30 },
    { time: '04:00', cpu: 52, memory: 65, disk: 32 },
    { time: '08:00', cpu: 78, memory: 72, disk: 35 },
    { time: '12:00', cpu: 85, memory: 80, disk: 38 },
    { time: '16:00', cpu: 92, memory: 85, disk: 40 },
    { time: '20:00', cpu: 68, memory: 70, disk: 42 },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Visão geral da infraestrutura</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Dispositivos</CardTitle>
            <Server className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDevices}</div>
            <p className="text-xs text-muted-foreground">
              {onlineDevices} online, {totalDevices - onlineDevices} offline
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dispositivos Online</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{onlineDevices}</div>
            <p className="text-xs text-muted-foreground">
              {totalDevices > 0 ? Math.round((onlineDevices / totalDevices) * 100) : 0}% do total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alertas Críticos</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{criticalAlerts}</div>
            <p className="text-xs text-muted-foreground">
              {alerts.length} alertas totais
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CPU Média</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgCpuUsage.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              Uso médio de CPU
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Performance Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Performance do Sistema</CardTitle>
            <CardDescription>Métricas das últimas 24 horas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="cpu" stroke="#3b82f6" strokeWidth={2} name="CPU %" />
                <Line type="monotone" dataKey="memory" stroke="#ef4444" strokeWidth={2} name="Memória %" />
                <Line type="monotone" dataKey="disk" stroke="#10b981" strokeWidth={2} name="Disco %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Alerts */}
        <Card>
          <CardHeader>
            <CardTitle>Alertas Recentes</CardTitle>
            <CardDescription>Últimos alertas do sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {alerts.length === 0 ? (
                <p className="text-gray-500 text-center py-4">Nenhum alerta ativo</p>
              ) : (
                alerts.slice(0, 5).map((alert, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className={`h-4 w-4 ${alert.severity === 'critical' ? 'text-red-500' : 'text-yellow-500'}`} />
                      <div>
                        <p className="text-sm font-medium">{alert.device_name}</p>
                        <p className="text-xs text-gray-600">{alert.message}</p>
                      </div>
                    </div>
                    <Badge variant={getSeverityColor(alert.severity)}>
                      {alert.severity}
                    </Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Device Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Status dos Dispositivos</CardTitle>
          <CardDescription>Visão geral de todos os dispositivos monitorados</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {overview.map((item) => (
              <div key={item.device.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(item.device.status)}`}></div>
                    <h3 className="font-medium">{item.device.name}</h3>
                  </div>
                  <Badge variant="outline">{item.device.operating_system}</Badge>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center">
                      <Cpu className="h-3 w-3 mr-1" />
                      CPU
                    </span>
                    <span>{item.latest_metrics?.cpu_percent?.toFixed(1) || 0}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center">
                      <MemoryStick className="h-3 w-3 mr-1" />
                      RAM
                    </span>
                    <span>{item.latest_metrics?.memory_percent?.toFixed(1) || 0}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center">
                      <HardDrive className="h-3 w-3 mr-1" />
                      Disco
                    </span>
                    <span>{item.latest_metrics?.disk_percent?.toFixed(1) || 0}%</span>
                  </div>
                </div>
                
                <div className="mt-3 text-xs text-gray-500">
                  Última atualização: {item.device.last_seen ? new Date(item.device.last_seen).toLocaleString('pt-BR') : 'Nunca'}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

