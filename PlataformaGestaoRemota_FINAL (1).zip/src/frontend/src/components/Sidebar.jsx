import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { 
  LayoutDashboard, 
  Server, 
  Activity, 
  Terminal, 
  FileTransfer,
  ChevronLeft,
  ChevronRight
} from 'lucide-react'

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false)
  const location = useLocation()

  const menuItems = [
    {
      path: '/dashboard',
      icon: LayoutDashboard,
      label: 'Dashboard',
      description: 'Visão geral do sistema'
    },
    {
      path: '/devices',
      icon: Server,
      label: 'Dispositivos',
      description: 'Gerenciar servidores'
    },
    {
      path: '/monitoring',
      icon: Activity,
      label: 'Monitoramento',
      description: 'Métricas em tempo real'
    },
    {
      path: '/commands',
      icon: Terminal,
      label: 'Comandos',
      description: 'Execução remota'
    },
    {
      path: '/files',
      icon: FileTransfer,
      label: 'Arquivos',
      description: 'Transferência de arquivos'
    }
  ]

  return (
    <div className={`bg-gray-900 text-white transition-all duration-300 ${collapsed ? 'w-16' : 'w-64'}`}>
      <div className="p-4">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <h1 className="text-xl font-bold">Infraestrutura</h1>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed(!collapsed)}
            className="text-white hover:bg-gray-800"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="mt-8">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.path

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 text-sm transition-colors hover:bg-gray-800 ${
                isActive ? 'bg-blue-600 border-r-4 border-blue-400' : ''
              }`}
            >
              <Icon className="h-5 w-5 flex-shrink-0" />
              {!collapsed && (
                <div className="ml-3">
                  <div className="font-medium">{item.label}</div>
                  <div className="text-xs text-gray-400">{item.description}</div>
                </div>
              )}
            </Link>
          )
        })}
      </nav>

      {!collapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-gray-800 rounded-lg p-3">
            <div className="text-xs text-gray-400">Status do Sistema</div>
            <div className="flex items-center mt-1">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              <span className="text-sm">Online</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Sidebar

