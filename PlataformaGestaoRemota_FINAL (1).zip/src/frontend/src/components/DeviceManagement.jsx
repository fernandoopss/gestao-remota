import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Server, 
  Plus, 
  Search, 
  MoreVertical, 
  Edit, 
  Trash2, 
  Power,
  Monitor,
  HardDrive
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const DeviceManagement = () => {
  const [devices, setDevices] = useState([])
  const [groups, setGroups] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    fetchDevices()
    fetchGroups()
  }, [])

  const fetchDevices = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/devices/')
      const data = await response.json()
      setDevices(data)
    } catch (error) {
      console.error('Error fetching devices:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchGroups = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/devices/groups')
      const data = await response.json()
      setGroups(data)
    } catch (error) {
      console.error('Error fetching groups:', error)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'bg-green-500'
      case 'offline': return 'bg-red-500'
      case 'error': return 'bg-yellow-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'online': return 'default'
      case 'offline': return 'destructive'
      case 'error': return 'secondary'
      default: return 'outline'
    }
  }

  const filteredDevices = devices.filter(device =>
    device.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    device.hostname.toLowerCase().includes(searchTerm.toLowerCase()) ||
    device.ip_address.includes(searchTerm)
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gerenciamento de Dispositivos</h1>
          <p className="text-gray-600">Gerencie servidores e estações de trabalho</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Adicionar Dispositivo
        </Button>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar por nome, hostname ou IP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">Filtros</Button>
          </div>
        </CardContent>
      </Card>

      {/* Device Groups */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {groups.map((group) => (
          <Card key={group.id}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{group.name}</CardTitle>
              <CardDescription>{group.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">{group.device_count} dispositivos</span>
                <Button variant="ghost" size="sm">Ver Todos</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Devices List */}
      <Card>
        <CardHeader>
          <CardTitle>Dispositivos ({filteredDevices.length})</CardTitle>
          <CardDescription>Lista de todos os dispositivos registrados</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredDevices.map((device) => (
              <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(device.status)}`}></div>
                    <Server className="h-8 w-8 text-gray-400" />
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900">{device.name}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>{device.hostname}</span>
                      <span>{device.ip_address}</span>
                      <Badge variant="outline">{device.operating_system}</Badge>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right text-sm">
                    <Badge variant={getStatusBadge(device.status)}>
                      {device.status}
                    </Badge>
                    <div className="text-gray-500 mt-1">
                      {device.last_seen ? new Date(device.last_seen).toLocaleString('pt-BR') : 'Nunca'}
                    </div>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Monitor className="h-4 w-4 mr-2" />
                        Monitorar
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Power className="h-4 w-4 mr-2" />
                        Comandos
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <HardDrive className="h-4 w-4 mr-2" />
                        Arquivos
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Remover
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>

          {filteredDevices.length === 0 && (
            <div className="text-center py-8">
              <Server className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum dispositivo encontrado</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? 'Tente ajustar os filtros de busca.' : 'Comece adicionando seu primeiro dispositivo.'}
              </p>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Dispositivo
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default DeviceManagement

