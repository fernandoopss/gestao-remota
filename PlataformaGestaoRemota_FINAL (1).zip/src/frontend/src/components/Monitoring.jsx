import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Activity, 
  Cpu, 
  MemoryStick, 
  HardDrive, 
  Wifi, 
  RefreshCw,
  TrendingUp,
  TrendingDown,
  AlertTriangle
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'

const Monitoring = () => {
  const [devices, setDevices] = useState([])
  const [selectedDevice, setSelectedDevice] = useState('')
  const [metrics, setMetrics] = useState([])
  const [latestMetrics, setLatestMetrics] = useState({})
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    fetchDevices()
  }, [])

  useEffect(() => {
    if (selectedDevice) {
      fetchMetrics(selectedDevice)
      fetchLatestMetrics(selectedDevice)
      
      // Auto-refresh every 10 seconds
      const interval = setInterval(() => {
        fetchMetrics(selectedDevice)
        fetchLatestMetrics(selectedDevice)
      }, 10000)

      return () => clearInterval(interval)
    }
  }, [selectedDevice])

  const fetchDevices = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/devices/')
      const data = await response.json()
      setDevices(data)
      if (data.length > 0 && !selectedDevice) {
        setSelectedDevice(data[0].id.toString())
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchMetrics = async (deviceId) => {
    try {
      const response = await fetch(`http://localhost:5000/api/monitoring/devices/${deviceId}/metrics?limit=50`)
      const data = await response.json()
      setMetrics(data)
    } catch (error) {
      console.error('Error fetching metrics:', error)
    }
  }

  const fetchLatestMetrics = async (deviceId) => {
    try {
      const response = await fetch(`http://localhost:5000/api/monitoring/devices/${deviceId}/metrics/latest`)
      const data = await response.json()
      setLatestMetrics(data)
    } catch (error) {
      console.error('Error fetching latest metrics:', error)
    }
  }

  const handleRefresh = async () => {
    if (!selectedDevice) return
    
    setRefreshing(true)
    await Promise.all([
      fetchMetrics(selectedDevice),
      fetchLatestMetrics(selectedDevice)
    ])
    setRefreshing(false)
  }

  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getMetricColor = (value, type) => {
    const thresholds = {
      cpu: { warning: 70, critical: 85 },
      memory: { warning: 75, critical: 90 },
      disk: { warning: 80, critical: 95 }
    }
    
    const threshold = thresholds[type]
    if (value >= threshold.critical) return 'text-red-600'
    if (value >= threshold.warning) return 'text-yellow-600'
    return 'text-green-600'
  }

  const getMetricBadge = (value, type) => {
    const thresholds = {
      cpu: { warning: 70, critical: 85 },
      memory: { warning: 75, critical: 90 },
      disk: { warning: 80, critical: 95 }
    }
    
    const threshold = thresholds[type]
    if (value >= threshold.critical) return 'destructive'
    if (value >= threshold.warning) return 'secondary'
    return 'default'
  }

  // Prepare chart data
  const chartData = metrics.map(metric => ({
    time: new Date(metric.timestamp).toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }),
    cpu: metric.cpu_percent,
    memory: metric.memory_percent,
    disk: metric.disk_percent,
    timestamp: metric.timestamp
  })).reverse()

  const selectedDeviceInfo = devices.find(d => d.id.toString() === selectedDevice)

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Monitoramento</h1>
          <p className="text-gray-600">Métricas em tempo real dos dispositivos</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedDevice} onValueChange={setSelectedDevice}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Selecione um dispositivo" />
            </SelectTrigger>
            <SelectContent>
              {devices.map((device) => (
                <SelectItem key={device.id} value={device.id.toString()}>
                  {device.name} ({device.ip_address})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>
      </div>

      {selectedDeviceInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>{selectedDeviceInfo.name}</span>
              <Badge variant={selectedDeviceInfo.status === 'online' ? 'default' : 'destructive'}>
                {selectedDeviceInfo.status}
              </Badge>
            </CardTitle>
            <CardDescription>
              {selectedDeviceInfo.hostname} • {selectedDeviceInfo.ip_address} • {selectedDeviceInfo.operating_system}
            </CardDescription>
          </CardHeader>
        </Card>
      )}

      {/* Current Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CPU</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getMetricColor(latestMetrics.cpu_percent || 0, 'cpu')}`}>
              {(latestMetrics.cpu_percent || 0).toFixed(1)}%
            </div>
            <Badge variant={getMetricBadge(latestMetrics.cpu_percent || 0, 'cpu')} className="mt-2">
              {latestMetrics.cpu_percent >= 85 ? 'Crítico' : latestMetrics.cpu_percent >= 70 ? 'Atenção' : 'Normal'}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Memória</CardTitle>
            <MemoryStick className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getMetricColor(latestMetrics.memory_percent || 0, 'memory')}`}>
              {(latestMetrics.memory_percent || 0).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {formatBytes(latestMetrics.memory_used || 0)} / {formatBytes(latestMetrics.memory_total || 0)}
            </p>
            <Badge variant={getMetricBadge(latestMetrics.memory_percent || 0, 'memory')} className="mt-2">
              {latestMetrics.memory_percent >= 90 ? 'Crítico' : latestMetrics.memory_percent >= 75 ? 'Atenção' : 'Normal'}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disco</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getMetricColor(latestMetrics.disk_percent || 0, 'disk')}`}>
              {(latestMetrics.disk_percent || 0).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {formatBytes(latestMetrics.disk_used || 0)} / {formatBytes(latestMetrics.disk_total || 0)}
            </p>
            <Badge variant={getMetricBadge(latestMetrics.disk_percent || 0, 'disk')} className="mt-2">
              {latestMetrics.disk_percent >= 95 ? 'Crítico' : latestMetrics.disk_percent >= 80 ? 'Atenção' : 'Normal'}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rede</CardTitle>
            <Wifi className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm">
              <div className="flex items-center justify-between">
                <span className="text-green-600">↓ {formatBytes(latestMetrics.network_bytes_recv || 0)}</span>
                <TrendingDown className="h-3 w-3 text-green-600" />
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-blue-600">↑ {formatBytes(latestMetrics.network_bytes_sent || 0)}</span>
                <TrendingUp className="h-3 w-3 text-blue-600" />
              </div>
            </div>
            <Badge variant="outline" className="mt-2">
              Ativo
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>CPU e Memória</CardTitle>
            <CardDescription>Histórico das últimas medições</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis domain={[0, 100]} />
                <Tooltip 
                  formatter={(value, name) => [`${value.toFixed(1)}%`, name === 'cpu' ? 'CPU' : 'Memória']}
                  labelFormatter={(label) => `Horário: ${label}`}
                />
                <Line type="monotone" dataKey="cpu" stroke="#3b82f6" strokeWidth={2} name="cpu" />
                <Line type="monotone" dataKey="memory" stroke="#ef4444" strokeWidth={2} name="memory" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Uso do Disco</CardTitle>
            <CardDescription>Monitoramento do espaço em disco</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis domain={[0, 100]} />
                <Tooltip 
                  formatter={(value) => [`${value.toFixed(1)}%`, 'Disco']}
                  labelFormatter={(label) => `Horário: ${label}`}
                />
                <Area type="monotone" dataKey="disk" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {(latestMetrics.cpu_percent >= 85 || latestMetrics.memory_percent >= 90 || latestMetrics.disk_percent >= 95) && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center text-red-800">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Alertas Críticos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {latestMetrics.cpu_percent >= 85 && (
                <div className="flex items-center text-red-700">
                  <Cpu className="h-4 w-4 mr-2" />
                  CPU em uso crítico: {latestMetrics.cpu_percent.toFixed(1)}%
                </div>
              )}
              {latestMetrics.memory_percent >= 90 && (
                <div className="flex items-center text-red-700">
                  <MemoryStick className="h-4 w-4 mr-2" />
                  Memória em uso crítico: {latestMetrics.memory_percent.toFixed(1)}%
                </div>
              )}
              {latestMetrics.disk_percent >= 95 && (
                <div className="flex items-center text-red-700">
                  <HardDrive className="h-4 w-4 mr-2" />
                  Disco em uso crítico: {latestMetrics.disk_percent.toFixed(1)}%
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Monitoring

