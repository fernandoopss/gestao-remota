import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Terminal, 
  Play, 
  Square, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  RefreshCw,
  History
} from 'lucide-react'

const Commands = () => {
  const [devices, setDevices] = useState([])
  const [selectedDevice, setSelectedDevice] = useState('')
  const [command, setCommand] = useState('')
  const [commands, setCommands] = useState([])
  const [loading, setLoading] = useState(true)
  const [executing, setExecuting] = useState(false)

  useEffect(() => {
    fetchDevices()
    fetchCommands()
    
    // Auto-refresh commands every 5 seconds
    const interval = setInterval(fetchCommands, 5000)
    return () => clearInterval(interval)
  }, [])

  const fetchDevices = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/devices/')
      const data = await response.json()
      setDevices(data.filter(device => device.status === 'online'))
    } catch (error) {
      console.error('Error fetching devices:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCommands = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/commands/history?limit=20')
      const data = await response.json()
      setCommands(data)
    } catch (error) {
      console.error('Error fetching commands:', error)
    }
  }

  const executeCommand = async () => {
    if (!selectedDevice || !command.trim()) return

    setExecuting(true)
    try {
      const response = await fetch('http://localhost:5000/api/commands/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          device_id: parseInt(selectedDevice),
          command: command.trim(),
          user_id: 1 // In production, get from JWT token
        }),
      })

      if (response.ok) {
        setCommand('')
        fetchCommands()
      }
    } catch (error) {
      console.error('Error executing command:', error)
    } finally {
      setExecuting(false)
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'running':
        return <Play className="h-4 w-4 text-blue-500" />
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return 'secondary'
      case 'running':
        return 'default'
      case 'completed':
        return 'default'
      case 'failed':
        return 'destructive'
      default:
        return 'outline'
    }
  }

  const formatDuration = (startTime, endTime) => {
    if (!startTime) return '-'
    
    const start = new Date(startTime)
    const end = endTime ? new Date(endTime) : new Date()
    const duration = Math.round((end - start) / 1000)
    
    if (duration < 60) return `${duration}s`
    if (duration < 3600) return `${Math.floor(duration / 60)}m ${duration % 60}s`
    return `${Math.floor(duration / 3600)}h ${Math.floor((duration % 3600) / 60)}m`
  }

  const quickCommands = [
    { label: 'Informações do Sistema', command: 'uname -a' },
    { label: 'Uso de Disco', command: 'df -h' },
    { label: 'Processos', command: 'ps aux | head -10' },
    { label: 'Memória', command: 'free -h' },
    { label: 'Uptime', command: 'uptime' },
    { label: 'Usuários Logados', command: 'who' },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Execução de Comandos</h1>
          <p className="text-gray-600">Execute comandos remotamente nos dispositivos</p>
        </div>
        <Button onClick={fetchCommands}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Command Execution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Terminal className="h-5 w-5 mr-2" />
            Executar Comando
          </CardTitle>
          <CardDescription>
            Selecione um dispositivo e digite o comando a ser executado
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Dispositivo</label>
              <Select value={selectedDevice} onValueChange={setSelectedDevice}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um dispositivo online" />
                </SelectTrigger>
                <SelectContent>
                  {devices.map((device) => (
                    <SelectItem key={device.id} value={device.id.toString()}>
                      {device.name} ({device.ip_address})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Comando</label>
            <Textarea
              placeholder="Digite o comando a ser executado..."
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex items-center justify-between">
            <Button
              onClick={executeCommand}
              disabled={!selectedDevice || !command.trim() || executing}
            >
              {executing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Executando...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Executar
                </>
              )}
            </Button>
          </div>

          {/* Quick Commands */}
          <div>
            <label className="text-sm font-medium mb-2 block">Comandos Rápidos</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {quickCommands.map((quickCmd, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => setCommand(quickCmd.command)}
                  className="text-left justify-start"
                >
                  {quickCmd.label}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Command History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <History className="h-5 w-5 mr-2" />
            Histórico de Comandos
          </CardTitle>
          <CardDescription>
            Últimos comandos executados nos dispositivos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {commands.length === 0 ? (
              <div className="text-center py-8">
                <Terminal className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum comando executado</h3>
                <p className="text-gray-600">Execute seu primeiro comando para ver o histórico aqui.</p>
              </div>
            ) : (
              commands.map((cmd) => (
                <div key={cmd.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(cmd.status)}
                      <div>
                        <div className="font-medium text-gray-900">{cmd.device_name}</div>
                        <div className="text-sm text-gray-600">
                          por {cmd.username} • {new Date(cmd.created_at).toLocaleString('pt-BR')}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={getStatusBadge(cmd.status)}>
                        {cmd.status}
                      </Badge>
                      {cmd.exit_code !== null && (
                        <Badge variant={cmd.exit_code === 0 ? 'default' : 'destructive'}>
                          Exit: {cmd.exit_code}
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm mb-3">
                    $ {cmd.command}
                  </div>

                  {cmd.output && (
                    <div className="bg-gray-50 p-3 rounded text-sm mb-2">
                      <div className="font-medium text-gray-700 mb-1">Saída:</div>
                      <pre className="whitespace-pre-wrap text-gray-900">{cmd.output}</pre>
                    </div>
                  )}

                  {cmd.error_output && (
                    <div className="bg-red-50 p-3 rounded text-sm mb-2">
                      <div className="font-medium text-red-700 mb-1">Erro:</div>
                      <pre className="whitespace-pre-wrap text-red-900">{cmd.error_output}</pre>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>
                      Duração: {formatDuration(cmd.started_at, cmd.completed_at)}
                    </span>
                    {cmd.completed_at && (
                      <span>
                        Concluído: {new Date(cmd.completed_at).toLocaleString('pt-BR')}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Commands

