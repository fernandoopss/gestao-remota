import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Upload, 
  Download, 
  File, 
  Folder, 
  RefreshCw, 
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle
} from 'lucide-react'

const FileTransfer = () => {
  const [devices, setDevices] = useState([])
  const [selectedDevice, setSelectedDevice] = useState('')
  const [transfers, setTransfers] = useState([])
  const [loading, setLoading] = useState(true)
  const [uploadFile, setUploadFile] = useState(null)
  const [downloadPath, setDownloadPath] = useState('')
  const [targetPath, setTargetPath] = useState('')

  useEffect(() => {
    fetchDevices()
    fetchTransfers()
    
    // Auto-refresh transfers every 5 seconds
    const interval = setInterval(fetchTransfers, 5000)
    return () => clearInterval(interval)
  }, [])

  const fetchDevices = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/devices/')
      const data = await response.json()
      setDevices(data.filter(device => device.status === 'online'))
    } catch (error) {
      console.error('Error fetching devices:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchTransfers = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/files/transfers?limit=20')
      const data = await response.json()
      setTransfers(data)
    } catch (error) {
      console.error('Error fetching transfers:', error)
    }
  }

  const handleUpload = async () => {
    if (!selectedDevice || !uploadFile) return

    const formData = new FormData()
    formData.append('file', uploadFile)
    formData.append('device_id', selectedDevice)
    formData.append('target_path', targetPath || `/tmp/${uploadFile.name}`)
    formData.append('user_id', '1') // In production, get from JWT token

    try {
      const response = await fetch('http://localhost:5000/api/files/upload', {
        method: 'POST',
        body: formData,
      })

      if (response.ok) {
        setUploadFile(null)
        setTargetPath('')
        fetchTransfers()
      }
    } catch (error) {
      console.error('Error uploading file:', error)
    }
  }

  const handleDownload = async () => {
    if (!selectedDevice || !downloadPath.trim()) return

    try {
      const response = await fetch('http://localhost:5000/api/files/request-download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          device_id: parseInt(selectedDevice),
          file_path: downloadPath.trim(),
          user_id: 1 // In production, get from JWT token
        }),
      })

      if (response.ok) {
        setDownloadPath('')
        fetchTransfers()
      }
    } catch (error) {
      console.error('Error requesting download:', error)
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'in_progress':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return 'secondary'
      case 'in_progress':
        return 'default'
      case 'completed':
        return 'default'
      case 'failed':
        return 'destructive'
      default:
        return 'outline'
    }
  }

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatDuration = (startTime, endTime) => {
    if (!startTime) return '-'
    
    const start = new Date(startTime)
    const end = endTime ? new Date(endTime) : new Date()
    const duration = Math.round((end - start) / 1000)
    
    if (duration < 60) return `${duration}s`
    if (duration < 3600) return `${Math.floor(duration / 60)}m ${duration % 60}s`
    return `${Math.floor(duration / 3600)}h ${Math.floor((duration % 3600) / 60)}m`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Transferência de Arquivos</h1>
          <p className="text-gray-600">Upload e download de arquivos nos dispositivos</p>
        </div>
        <Button onClick={fetchTransfers}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="h-5 w-5 mr-2" />
              Upload de Arquivo
            </CardTitle>
            <CardDescription>
              Envie arquivos para um dispositivo remoto
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Dispositivo</label>
              <Select value={selectedDevice} onValueChange={setSelectedDevice}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um dispositivo online" />
                </SelectTrigger>
                <SelectContent>
                  {devices.map((device) => (
                    <SelectItem key={device.id} value={device.id.toString()}>
                      {device.name} ({device.ip_address})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Arquivo</label>
              <Input
                type="file"
                onChange={(e) => setUploadFile(e.target.files[0])}
              />
              {uploadFile && (
                <div className="mt-2 text-sm text-gray-600">
                  <File className="h-4 w-4 inline mr-1" />
                  {uploadFile.name} ({formatFileSize(uploadFile.size)})
                </div>
              )}
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Caminho de Destino (opcional)</label>
              <Input
                placeholder="/caminho/para/arquivo"
                value={targetPath}
                onChange={(e) => setTargetPath(e.target.value)}
              />
              <div className="text-xs text-gray-500 mt-1">
                Se não especificado, será salvo em /tmp/
              </div>
            </div>

            <Button
              onClick={handleUpload}
              disabled={!selectedDevice || !uploadFile}
              className="w-full"
            >
              <Upload className="h-4 w-4 mr-2" />
              Enviar Arquivo
            </Button>
          </CardContent>
        </Card>

        {/* Download Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Download className="h-5 w-5 mr-2" />
              Download de Arquivo
            </CardTitle>
            <CardDescription>
              Baixe arquivos de um dispositivo remoto
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Dispositivo</label>
              <Select value={selectedDevice} onValueChange={setSelectedDevice}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um dispositivo online" />
                </SelectTrigger>
                <SelectContent>
                  {devices.map((device) => (
                    <SelectItem key={device.id} value={device.id.toString()}>
                      {device.name} ({device.ip_address})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Caminho do Arquivo</label>
              <Input
                placeholder="/caminho/para/arquivo"
                value={downloadPath}
                onChange={(e) => setDownloadPath(e.target.value)}
              />
              <div className="text-xs text-gray-500 mt-1">
                Caminho completo do arquivo no dispositivo remoto
              </div>
            </div>

            <Button
              onClick={handleDownload}
              disabled={!selectedDevice || !downloadPath.trim()}
              className="w-full"
            >
              <Download className="h-4 w-4 mr-2" />
              Solicitar Download
            </Button>

            <div className="border-t pt-4">
              <h4 className="text-sm font-medium mb-2">Caminhos Comuns</h4>
              <div className="grid grid-cols-1 gap-1">
                {[
                  '/var/log/syslog',
                  '/etc/hosts',
                  '/proc/cpuinfo',
                  '/home/user/documents/',
                  '/tmp/'
                ].map((path) => (
                  <Button
                    key={path}
                    variant="ghost"
                    size="sm"
                    onClick={() => setDownloadPath(path)}
                    className="justify-start text-xs"
                  >
                    <Folder className="h-3 w-3 mr-1" />
                    {path}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transfer History */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Transferências</CardTitle>
          <CardDescription>
            Últimas transferências de arquivos realizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transfers.length === 0 ? (
              <div className="text-center py-8">
                <File className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma transferência</h3>
                <p className="text-gray-600">Faça upload ou download de arquivos para ver o histórico aqui.</p>
              </div>
            ) : (
              transfers.map((transfer) => (
                <div key={transfer.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(transfer.status)}
                      <div className="flex items-center space-x-2">
                        {transfer.operation_type === 'upload' ? (
                          <Upload className="h-4 w-4 text-blue-500" />
                        ) : (
                          <Download className="h-4 w-4 text-green-500" />
                        )}
                        <div>
                          <div className="font-medium text-gray-900">{transfer.filename}</div>
                          <div className="text-sm text-gray-600">
                            {transfer.device_name} • por {transfer.username}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={getStatusBadge(transfer.status)}>
                        {transfer.status}
                      </Badge>
                      <Badge variant="outline">
                        {transfer.operation_type}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Caminho:</span>
                      <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                        {transfer.file_path}
                      </span>
                    </div>
                    
                    {transfer.file_size && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Tamanho:</span>
                        <span>{formatFileSize(transfer.file_size)}</span>
                      </div>
                    )}

                    {transfer.status === 'in_progress' && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Progresso:</span>
                          <span>{transfer.progress.toFixed(1)}%</span>
                        </div>
                        <Progress value={transfer.progress} className="h-2" />
                      </div>
                    )}

                    {transfer.error_message && (
                      <div className="bg-red-50 p-2 rounded text-sm text-red-700">
                        <strong>Erro:</strong> {transfer.error_message}
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t">
                      <span>
                        Criado: {new Date(transfer.created_at).toLocaleString('pt-BR')}
                      </span>
                      {transfer.completed_at && (
                        <span>
                          Duração: {formatDuration(transfer.started_at, transfer.completed_at)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default FileTransfer

